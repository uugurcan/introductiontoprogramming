-- SOLUTION: Exercise 07 — Advanced SQL
-- ⚠️  Try the exercise yourself first!

.headers on
.mode column

-- 7.1: Index on students.gpa
CREATE INDEX IF NOT EXISTS idx_students_gpa ON students(gpa);

EXPLAIN QUERY PLAN
SELECT * FROM students WHERE gpa > 3.5;
-- You should see "SEARCH students USING INDEX idx_students_gpa"

-- 7.2: View — enrollment details
DROP VIEW IF EXISTS enrollment_details;

CREATE VIEW enrollment_details AS
SELECT
    s.first_name || ' ' || s.last_name AS student_name,
    c.code AS course_code,
    c.title AS course_title,
    g.letter_grade
FROM enrollments e
INNER JOIN students s ON e.student_id = s.id
INNER JOIN courses c ON e.course_id = c.id
LEFT JOIN grades g ON e.id = g.enrollment_id;

-- Query the view for A grades
SELECT * FROM enrollment_details
WHERE letter_grade = 'A'
ORDER BY student_name;

-- 7.3: View — course statistics
DROP VIEW IF EXISTS course_statistics;

CREATE VIEW course_statistics AS
SELECT
    c.code,
    c.title,
    COUNT(e.id) AS enrolled_students,
    ROUND(AVG(g.final), 1) AS avg_final_score
FROM courses c
LEFT JOIN enrollments e ON c.id = e.course_id
LEFT JOIN grades g ON e.id = g.enrollment_id
GROUP BY c.id;

SELECT * FROM course_statistics ORDER BY enrolled_students DESC;

-- 7.4: Insert new student
INSERT INTO students (first_name, last_name, email, enrollment_year, gpa)
VALUES ('New', 'Student', 'newstudent@school.edu', 2024, NULL);

-- Verify
SELECT * FROM students WHERE email = 'newstudent@school.edu';

-- 7.5: Update Quinn Moore's GPA
UPDATE students
SET gpa = 3.22
WHERE id = 17;

-- Verify
SELECT first_name, last_name, gpa FROM students WHERE id = 17;

-- 7.6: Safe delete of F grades
-- Step 1: Preview what will be deleted
SELECT g.*, e.student_id, e.course_id
FROM grades g
INNER JOIN enrollments e ON g.enrollment_id = e.id
WHERE g.letter_grade = 'F';

-- Step 2: Delete
DELETE FROM grades
WHERE letter_grade = 'F';

-- 7.7: Transaction — enroll student 1 in course 13
BEGIN TRANSACTION;

INSERT INTO enrollments (student_id, course_id, enrollment_date)
VALUES (1, 13, DATE('now'));

INSERT INTO grades (enrollment_id, midterm, final, assignments, letter_grade)
VALUES (last_insert_rowid(), NULL, NULL, NULL, NULL);

COMMIT;

-- Verify
SELECT e.id, e.student_id, e.course_id, g.letter_grade
FROM enrollments e
LEFT JOIN grades g ON e.id = g.enrollment_id
WHERE e.student_id = 1 AND e.course_id = 13;

-- 7.8: Transaction — library loan (run against library.db)
-- First check availability:
-- SELECT available_copies FROM books WHERE id = 3;

BEGIN TRANSACTION;

UPDATE books
SET available_copies = available_copies - 1
WHERE id = 3 AND available_copies > 0;

-- Check that the update affected 1 row (book was available)
-- In a real app you'd check changes() > 0

INSERT INTO loans (member_id, book_id, loan_date, due_date)
VALUES (3, 3, DATE('now'), DATE('now', '+14 days'));

COMMIT;

-- 7.9: EXPLAIN QUERY PLAN comparison

-- Make sure email index exists:
CREATE INDEX IF NOT EXISTS idx_students_email ON students(email);

-- Version A — SQLite cannot use index because LOWER() wraps the column
EXPLAIN QUERY PLAN
SELECT * FROM students WHERE LOWER(email) = 'alice@school.edu';
-- Result: SCAN students (full table scan)

-- Version B — index can be used directly
EXPLAIN QUERY PLAN
SELECT * FROM students WHERE email = 'alice@school.edu';
-- Result: SEARCH students USING INDEX idx_students_email

-- EXPLANATION:
-- When you wrap a column in a function like LOWER(email), SQLite cannot
-- use the index because the index stores the original values, not the
-- lowercase versions. SQLite has to compute LOWER() for EVERY row and
-- compare it, resulting in a full table scan.
-- Version B lets SQLite use the index directly for an O(log n) lookup.

-- 7.10 CHALLENGE: Compound index
CREATE INDEX IF NOT EXISTS idx_enrollments_student_course
    ON enrollments(student_id, course_id);

EXPLAIN QUERY PLAN
SELECT * FROM enrollments WHERE student_id = 5 AND course_id = 1;
-- Should show: SEARCH enrollments USING INDEX idx_enrollments_student_course
