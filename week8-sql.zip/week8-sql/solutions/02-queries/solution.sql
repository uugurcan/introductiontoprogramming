-- SOLUTION: Exercise 02 — Querying Data
-- ⚠️  Try the exercise yourself first!

.headers on
.mode column

-- 2.1: Students whose last name contains 's'
SELECT first_name, last_name
FROM students
WHERE last_name LIKE '%s%';

-- 2.2: Teachers with email ending in @cs50.harvard.edu
SELECT first_name, last_name, email
FROM teachers
WHERE email LIKE '%@cs50.harvard.edu';

-- 2.3: Top 5 students by GPA
SELECT first_name, last_name, gpa
FROM students
WHERE gpa IS NOT NULL
ORDER BY gpa DESC
LIMIT 5;

-- 2.4: Distinct enrollment years
SELECT DISTINCT enrollment_year
FROM students
ORDER BY enrollment_year;

-- 2.5: Courses in department 1 or 2
SELECT code, title, department_id
FROM courses
WHERE department_id IN (1, 2);

-- 2.6: Students who did NOT enroll in 2018
SELECT first_name, last_name, enrollment_year
FROM students
WHERE enrollment_year NOT IN (2018);

-- 2.7: Courses sorted by credits desc, then title asc
SELECT code, title, credits
FROM courses
ORDER BY credits DESC, title ASC;

-- 2.8: Books starting with 'The' (run against library.db)
SELECT title, published_year
FROM books
WHERE title LIKE 'The%';

-- 2.9: Loans with no return date (run against library.db)
SELECT id, member_id, due_date
FROM loans
WHERE return_date IS NULL;

-- 2.10: British authors sorted by last name (run against library.db)
SELECT first_name, last_name
FROM authors
WHERE nationality = 'British'
ORDER BY last_name;

-- 2.11: Premium and student members (run against library.db)
SELECT first_name, last_name, membership_type
FROM members
WHERE membership_type IN ('premium', 'student');

-- 2.12 CHALLENGE: Students with exactly 4-letter first names
SELECT first_name, last_name
FROM students
WHERE first_name LIKE '____';
