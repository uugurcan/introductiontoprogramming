-- SOLUTION: Exercise 04 — Aggregates
-- ⚠️  Try the exercise yourself first!

.headers on
.mode column

-- 4.1: Total number of students
SELECT COUNT(*) AS total_students
FROM students;

-- 4.2: Students per enrollment year
SELECT enrollment_year, COUNT(*) AS count
FROM students
GROUP BY enrollment_year
ORDER BY enrollment_year;

-- 4.3: Average GPA
SELECT ROUND(AVG(gpa), 2) AS average_gpa
FROM students;

-- 4.4: Highest, lowest, and average GPA
SELECT MAX(gpa) AS highest,
       MIN(gpa) AS lowest,
       ROUND(AVG(gpa), 2) AS average
FROM students;

-- 4.5: Courses per department
SELECT department_id, COUNT(*) AS course_count
FROM courses
GROUP BY department_id
ORDER BY department_id;

-- 4.6: Students per course
SELECT course_id, COUNT(*) AS student_count
FROM enrollments
GROUP BY course_id
ORDER BY student_count DESC;

-- 4.7: Courses with more than 3 students
SELECT course_id, COUNT(*) AS student_count
FROM enrollments
GROUP BY course_id
HAVING COUNT(*) > 3
ORDER BY student_count DESC;

-- 4.8: Average final score per course
SELECT e.course_id,
       ROUND(AVG(g.final), 1) AS avg_final
FROM enrollments e
INNER JOIN grades g ON e.id = g.enrollment_id
WHERE g.final IS NOT NULL
GROUP BY e.course_id
ORDER BY avg_final DESC;

-- 4.9: Department salary stats
SELECT department_id,
       COUNT(*) AS teacher_count,
       ROUND(AVG(salary)) AS avg_salary,
       MAX(salary) AS max_salary
FROM teachers
GROUP BY department_id;

-- 4.10: Total and average fines (library.db)
SELECT SUM(fine) AS total_fines,
       ROUND(AVG(fine), 2) AS avg_fine_when_fined
FROM loans
WHERE fine > 0;

-- 4.11: Books per genre (library.db)
SELECT genre_id, COUNT(*) AS book_count
FROM books
GROUP BY genre_id
ORDER BY book_count DESC;

-- 4.12 CHALLENGE: Departments with avg salary > 75000
SELECT department_id,
       ROUND(AVG(salary)) AS avg_salary
FROM teachers
GROUP BY department_id
HAVING AVG(salary) > 75000
ORDER BY avg_salary DESC;
