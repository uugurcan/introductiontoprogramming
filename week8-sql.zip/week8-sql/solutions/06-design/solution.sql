-- SOLUTION: Exercise 06 — Database Design
-- ⚠️  Try the exercise yourself first!

-- ============================================================
-- 6.1 — Social Media Schema
-- ============================================================

CREATE TABLE IF NOT EXISTS users (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    username TEXT UNIQUE NOT NULL,
    email TEXT UNIQUE NOT NULL,
    bio TEXT,
    join_date TEXT NOT NULL DEFAULT (DATE('now'))
);

CREATE TABLE IF NOT EXISTS posts (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id INTEGER NOT NULL,
    content TEXT NOT NULL,
    created_at TEXT NOT NULL DEFAULT (DATETIME('now')),
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
);

CREATE TABLE IF NOT EXISTS follows (
    follower_id INTEGER NOT NULL,
    followed_id INTEGER NOT NULL,
    followed_at TEXT DEFAULT (DATETIME('now')),
    PRIMARY KEY (follower_id, followed_id),
    FOREIGN KEY (follower_id) REFERENCES users(id),
    FOREIGN KEY (followed_id) REFERENCES users(id),
    CHECK (follower_id != followed_id)  -- can't follow yourself
);

CREATE TABLE IF NOT EXISTS likes (
    user_id INTEGER NOT NULL,
    post_id INTEGER NOT NULL,
    liked_at TEXT DEFAULT (DATETIME('now')),
    PRIMARY KEY (user_id, post_id),
    FOREIGN KEY (user_id) REFERENCES users(id),
    FOREIGN KEY (post_id) REFERENCES posts(id) ON DELETE CASCADE
);

CREATE TABLE IF NOT EXISTS comments (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    post_id INTEGER NOT NULL,
    user_id INTEGER NOT NULL,
    content TEXT NOT NULL,
    created_at TEXT DEFAULT (DATETIME('now')),
    FOREIGN KEY (post_id) REFERENCES posts(id) ON DELETE CASCADE,
    FOREIGN KEY (user_id) REFERENCES users(id)
);

-- ============================================================
-- 6.2 — Movie Rental Schema
-- ============================================================

CREATE TABLE IF NOT EXISTS genres (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT UNIQUE NOT NULL
);

CREATE TABLE IF NOT EXISTS movies (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    title TEXT NOT NULL,
    release_year INTEGER,
    rating TEXT CHECK(rating IN ('G', 'PG', 'PG-13', 'R', 'NC-17')),
    genre_id INTEGER,
    FOREIGN KEY (genre_id) REFERENCES genres(id)
);

CREATE TABLE IF NOT EXISTS copies (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    movie_id INTEGER NOT NULL,
    condition TEXT CHECK(condition IN ('good', 'fair', 'damaged')) DEFAULT 'good',
    FOREIGN KEY (movie_id) REFERENCES movies(id)
);

CREATE TABLE IF NOT EXISTS customers (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    first_name TEXT NOT NULL,
    last_name TEXT NOT NULL,
    email TEXT UNIQUE NOT NULL,
    phone TEXT
);

CREATE TABLE IF NOT EXISTS rentals (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    customer_id INTEGER NOT NULL,
    copy_id INTEGER NOT NULL,
    rental_date TEXT NOT NULL DEFAULT (DATE('now')),
    due_date TEXT NOT NULL,
    return_date TEXT,
    FOREIGN KEY (customer_id) REFERENCES customers(id),
    FOREIGN KEY (copy_id) REFERENCES copies(id)
);

CREATE TABLE IF NOT EXISTS reviews (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    customer_id INTEGER NOT NULL,
    movie_id INTEGER NOT NULL,
    rating INTEGER CHECK(rating BETWEEN 1 AND 5),
    review_text TEXT,
    created_at TEXT DEFAULT (DATE('now')),
    UNIQUE(customer_id, movie_id),  -- one review per customer per movie
    FOREIGN KEY (customer_id) REFERENCES customers(id),
    FOREIGN KEY (movie_id) REFERENCES movies(id)
);

-- ============================================================
-- 6.3 — E-Commerce Schema
-- ============================================================

CREATE TABLE IF NOT EXISTS categories (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT NOT NULL,
    parent_id INTEGER,  -- self-referential for subcategories
    FOREIGN KEY (parent_id) REFERENCES categories(id)
);

CREATE TABLE IF NOT EXISTS products (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT NOT NULL,
    description TEXT,
    price REAL NOT NULL CHECK(price >= 0),
    stock_count INTEGER NOT NULL DEFAULT 0 CHECK(stock_count >= 0),
    category_id INTEGER,
    FOREIGN KEY (category_id) REFERENCES categories(id)
);

CREATE TABLE IF NOT EXISTS order_customers (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    first_name TEXT NOT NULL,
    last_name TEXT NOT NULL,
    email TEXT UNIQUE NOT NULL,
    address TEXT
);

CREATE TABLE IF NOT EXISTS orders (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    customer_id INTEGER NOT NULL,
    order_date TEXT DEFAULT (DATETIME('now')),
    status TEXT CHECK(status IN ('pending', 'shipped', 'delivered', 'cancelled')) DEFAULT 'pending',
    FOREIGN KEY (customer_id) REFERENCES order_customers(id)
);

CREATE TABLE IF NOT EXISTS order_items (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    order_id INTEGER NOT NULL,
    product_id INTEGER NOT NULL,
    quantity INTEGER NOT NULL CHECK(quantity > 0),
    -- Store price at time of purchase (not reference to current price!)
    unit_price REAL NOT NULL CHECK(unit_price >= 0),
    FOREIGN KEY (order_id) REFERENCES orders(id),
    FOREIGN KEY (product_id) REFERENCES products(id)
);

-- ============================================================
-- 6.4 — Problems with the Bad Schema
-- ============================================================

-- PROBLEMS:
-- 1. `info TEXT` — No primary key! Vague column name.
-- 2. `name_and_email TEXT` — Stores TWO values in one column (not atomic, violates 1NF)
-- 3. `courses TEXT` — Comma-separated list in one cell (violates 1NF)
-- 4. `gpa TEXT` — Wrong type! GPA is numeric, should be REAL
-- 5. `teacher_name TEXT` — Teacher data doesn't belong here (data duplication, violates 3NF)
-- 6. `teacher_salary TEXT` — Wrong type (REAL), and belongs in its own teachers table

-- FIXED SCHEMA:
CREATE TABLE IF NOT EXISTS fixed_students (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    first_name TEXT NOT NULL,
    last_name TEXT NOT NULL,
    email TEXT UNIQUE NOT NULL,
    gpa REAL
);

CREATE TABLE IF NOT EXISTS fixed_teachers (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT NOT NULL,
    salary REAL NOT NULL
);

CREATE TABLE IF NOT EXISTS fixed_courses (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    title TEXT NOT NULL,
    teacher_id INTEGER,
    FOREIGN KEY (teacher_id) REFERENCES fixed_teachers(id)
);

CREATE TABLE IF NOT EXISTS fixed_enrollments (
    student_id INTEGER NOT NULL,
    course_id INTEGER NOT NULL,
    PRIMARY KEY (student_id, course_id),
    FOREIGN KEY (student_id) REFERENCES fixed_students(id),
    FOREIGN KEY (course_id) REFERENCES fixed_courses(id)
);

-- ============================================================
-- 6.5 — Seed Social Media Data
-- ============================================================

INSERT OR IGNORE INTO users (username, email, bio) VALUES
    ('alice_dev', 'alice@dev.io', 'I love SQL!'),
    ('bob_learns', 'bob@learn.io', 'CS50 student'),
    ('carol_codes', 'carol@code.io', 'Python & databases'),
    ('david_data', 'david@data.io', 'Data nerd'),
    ('eva_eng', 'eva@eng.io', 'Software engineer');

INSERT OR IGNORE INTO posts (user_id, content) VALUES
    (1, 'Just learned about JOINs. Mind blown!'),
    (1, 'SQL is just asking questions in a very specific way.'),
    (2, 'CS50 Week 7 is no joke...'),
    (3, 'GROUP BY is your friend for reports.'),
    (3, 'Spent 3 hours on a missing semicolon. Help.'),
    (4, 'Indexes make queries SO much faster.'),
    (4, 'Normalized my first database schema today!'),
    (5, 'Hot take: SQL is more elegant than most ORMs.'),
    (5, 'Anyone else think NULL is confusing?'),
    (2, 'Finally got subqueries. Only took 10 tries.');

INSERT OR IGNORE INTO follows (follower_id, followed_id) VALUES
    (1, 2), (1, 3), (2, 1), (3, 1), (4, 1), (4, 5), (5, 3);

INSERT OR IGNORE INTO likes (user_id, post_id) VALUES
    (2, 1), (3, 1), (4, 1), (5, 1),
    (1, 3), (3, 3), (4, 3),
    (1, 8), (2, 8), (3, 8), (4, 8), (5, 8),
    (2, 6), (3, 6),
    (1, 10), (4, 10), (5, 10);

INSERT OR IGNORE INTO comments (post_id, user_id, content) VALUES
    (1, 2, 'INNER JOIN specifically made sense to me today!'),
    (1, 3, 'Wait until you see self-joins...'),
    (3, 1, 'You''ve got this! Keep going.'),
    (8, 2, 'I disagree but I respect the take.'),
    (9, 4, 'NULL means unknown. Once that clicked it helped me a lot.');

-- Verification Q1: Who does user 1 follow?
SELECT u.username
FROM follows f
INNER JOIN users u ON f.followed_id = u.id
WHERE f.follower_id = 1;

-- Verification Q2: Most liked posts?
SELECT p.content, COUNT(l.post_id) AS like_count
FROM posts p
LEFT JOIN likes l ON p.id = l.post_id
GROUP BY p.id
ORDER BY like_count DESC;

-- Verification Q3: User who posted the most?
SELECT u.username, COUNT(p.id) AS post_count
FROM users u
LEFT JOIN posts p ON u.id = p.user_id
GROUP BY u.id
ORDER BY post_count DESC
LIMIT 1;
