-- SOLUTION: Exercise 05 — Subqueries
-- ⚠️  Try the exercise yourself first!

.headers on
.mode column

-- 5.1: Students with above-average GPA
SELECT first_name, last_name, gpa
FROM students
WHERE gpa > (SELECT AVG(gpa) FROM students)
ORDER BY gpa DESC;

-- 5.2: Students enrolled in CS50
SELECT first_name, last_name
FROM students
WHERE id IN (
    SELECT student_id FROM enrollments
    WHERE course_id = (SELECT id FROM courses WHERE code = 'CS50')
);

-- 5.3: Students NOT enrolled in CS50
SELECT first_name, last_name
FROM students
WHERE id NOT IN (
    SELECT student_id FROM enrollments
    WHERE course_id = (SELECT id FROM courses WHERE code = 'CS50')
);

-- 5.4: Courses taught by the highest-paid teacher
SELECT code, title
FROM courses
WHERE teacher_id = (
    SELECT id FROM teachers
    ORDER BY salary DESC
    LIMIT 1
);

-- 5.5: Students enrolled in 3+ courses (subquery in FROM)
SELECT s.first_name, s.last_name, ec.course_count
FROM students s
INNER JOIN (
    SELECT student_id, COUNT(*) AS course_count
    FROM enrollments
    GROUP BY student_id
    HAVING COUNT(*) >= 3
) AS ec ON s.id = ec.student_id
ORDER BY ec.course_count DESC;

-- 5.6: Members who borrowed more than 2 books (library.db)
SELECT first_name, last_name
FROM members
WHERE id IN (
    SELECT member_id FROM loans
    GROUP BY member_id
    HAVING COUNT(*) > 2
);

-- 5.7: Books above average page count (library.db)
SELECT title, pages
FROM books
WHERE pages > (SELECT AVG(pages) FROM books)
ORDER BY pages DESC;

-- 5.8: Students with at least one grade (EXISTS)
SELECT s.first_name, s.last_name
FROM students s
WHERE EXISTS (
    SELECT 1 FROM enrollments e
    INNER JOIN grades g ON e.id = g.enrollment_id
    WHERE e.student_id = s.id
      AND g.final IS NOT NULL
);

-- 5.9: Courses with no grades (NOT EXISTS)
SELECT c.code, c.title
FROM courses c
WHERE NOT EXISTS (
    SELECT 1 FROM enrollments e
    INNER JOIN grades g ON e.id = g.enrollment_id
    WHERE e.course_id = c.id
      AND g.final IS NOT NULL
);

-- 5.10 CHALLENGE: Course(s) with most enrollments (no LIMIT)
SELECT course_id, COUNT(*) AS enrollment_count
FROM enrollments
GROUP BY course_id
HAVING COUNT(*) = (
    SELECT MAX(cnt) FROM (
        SELECT COUNT(*) AS cnt
        FROM enrollments
        GROUP BY course_id
    )
);
